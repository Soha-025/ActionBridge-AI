/**
 * ConfirmModal (M1-owned): shows a REAL pending schedule change and lets the
 * human apply or cancel it through the actual backend endpoints.
 *
 * Guarantees required by the brief:
 * - Fetches real change details via GET /api/changes/{id}.
 * - Compares old vs new dates and lists affected/rebalanced tasks.
 * - States plainly that nothing is applied yet.
 * - Separate Apply / Cancel actions that hit the real endpoints.
 * - Blocks duplicate requests, shows progress, surfaces meaningful errors.
 * - Success is reported only from the server's own response body, never
 *   assumed from a 2xx status or patched together on the client.
 * - A 409 on Apply/Cancel is treated as "this proposal is no longer pending":
 *   the modal re-reads the server's record instead of guessing at the outcome.
 * - On successful apply, notifies the parent so the dashboard refreshes.
 * - Closing the modal (X / Esc / backdrop) NEVER cancels the server proposal.
 *   The proposal stays pending and the parent keeps a way to reopen it.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { api, ApiError } from "../api";
import type { ApplyChangeResponse, CancelChangeResponse, ChangeDetail } from "../types";

interface ConfirmModalProps {
  /** The change id to inspect. When null/empty the modal renders nothing. */
  changeId: string | null;
  open: boolean;
  /** Dismiss the UI only — does NOT cancel the pending server change. */
  onClose: () => void;
  /** Called with the server's apply result after a successful apply. */
  onApplied: (result: ApplyChangeResponse) => void;
  /** Called with the server's cancel result after a successful cancel. */
  onCancelled: (changeId: string, result: CancelChangeResponse) => void;
  /** Reports the status the server actually returned for this change id, so
   *  the parent can drop proposals that are no longer actionable. */
  onStatusObserved?: (changeId: string, status: string) => void;
  /** Reports a failed load with its HTTP status, so the parent can forget an
   *  id the server says does not exist (404) while keeping one that only had a
   *  transient network failure. */
  onLoadError?: (changeId: string, status: number) => void;
}

type Phase = "loading" | "ready" | "error";

export default function ConfirmModal({
  changeId,
  open,
  onClose,
  onApplied,
  onCancelled,
  onStatusObserved,
  onLoadError,
}: ConfirmModalProps) {
  const [phase, setPhase] = useState<Phase>("loading");
  const [change, setChange] = useState<ChangeDetail | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  // "idle" | "applying" | "cancelling" — also used to block duplicate clicks.
  const [busy, setBusy] = useState<"idle" | "applying" | "cancelling">("idle");

  const dialogRef = useRef<HTMLDivElement>(null);
  const primaryRef = useRef<HTMLButtonElement>(null);

  // Fetch whenever the modal opens with a change id.
  useEffect(() => {
    if (open && changeId) {
      // Guard against stale responses if the id changes quickly.
      let cancelled = false;
      setPhase("loading");
      setLoadError(null);
      setActionError(null);
      setBusy("idle");
      api
        .getChange(changeId)
        .then((detail) => {
          if (cancelled) return;
          setChange(detail);
          setPhase("ready");
          // Tell the parent what the server really thinks of this proposal.
          onStatusObserved?.(changeId, detail.status);
          requestAnimationFrame(() => primaryRef.current?.focus());
        })
        .catch((err) => {
          if (cancelled) return;
          const status = err instanceof ApiError ? err.status : 0;
          setLoadError(
            err instanceof ApiError ? err.message : "Could not load this change. Please try again.",
          );
          setPhase("error");
          // 404 = the server has no such proposal; anything else may be transient.
          if (status === 404) onLoadError?.(changeId, status);
        });
      return () => {
        cancelled = true;
      };
    }
    return undefined;
  }, [open, changeId, onStatusObserved, onLoadError]);

  // Esc dismisses (UI only) and simple focus containment.
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const stillPending = useMemo(
    () => !change || change.status === "pending",
    [change],
  );

  /**
   * A 409 means the server already moved this proposal out of "pending" (applied
   * or cancelled elsewhere, or a double click). Rather than guess which, re-read
   * the authoritative record from GET /api/changes/{id} and show that.
   */
  const resyncAfterRejection = useCallback(async (id: string): Promise<string | null> => {
    try {
      const fresh = await api.getChange(id);
      setChange(fresh);
      setPhase("ready");
      onStatusObserved?.(id, fresh.status);
      return fresh.status;
    } catch {
      return null;
    }
  }, [onStatusObserved]);

  const handleApply = useCallback(async () => {
    if (!changeId || busy !== "idle" || !stillPending) return;
    setBusy("applying");
    setActionError(null);
    try {
      const result = await api.applyChange(changeId);
      if (result.status !== "applied") {
        // The server answered, but not with an applied change: say so instead
        // of claiming success, and let the parent prune the stale proposal.
        onStatusObserved?.(changeId, result.status);
        setActionError(
          `The backend did not apply this change (server status: "${result.status}"). Your plan is unchanged.`,
        );
        setBusy("idle");
        return;
      }
      onStatusObserved?.(changeId, result.status);
      onApplied(result);
      onClose();
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        const status = await resyncAfterRejection(changeId);
        setActionError(
          status
            ? `Nothing was applied: the server already recorded this proposal as “${status}”. The details shown now come from the server.`
            : `The backend rejected this apply (409) and its current status could not be read. Your plan is unchanged.`,
        );
        setBusy("idle");
        return;
      }
      setActionError(
        err instanceof ApiError
          ? `Could not apply the change: ${err.message}`
          : "Could not apply the change. Please try again.",
      );
      setBusy("idle");
    }
  }, [changeId, busy, stillPending, onApplied, onClose, onStatusObserved, resyncAfterRejection]);

  const handleCancel = useCallback(async () => {
    if (!changeId || busy !== "idle") return;
    setBusy("cancelling");
    setActionError(null);
    try {
      const result = await api.cancelChange(changeId);
      if (result.status !== "cancelled") {
        onStatusObserved?.(changeId, result.status);
        setActionError(
          `The backend did not cancel this proposal (server status: "${result.status}").`,
        );
        setBusy("idle");
        return;
      }
      onStatusObserved?.(changeId, result.status);
      onCancelled(changeId, result);
      onClose();
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        const status = await resyncAfterRejection(changeId);
        setActionError(
          status
            ? `Nothing to cancel: the server already recorded this proposal as “${status}”.`
            : `The backend rejected this cancel (409) and its current status could not be read.`,
        );
        setBusy("idle");
        return;
      }
      setActionError(
        err instanceof ApiError
          ? `Could not cancel the proposal: ${err.message}`
          : "Could not cancel the proposal. Please try again.",
      );
      setBusy("idle");
    }
  }, [changeId, busy, onCancelled, onClose, onStatusObserved, resyncAfterRejection]);

  if (!open || !changeId) return null;

  const affectedCount =
    (change ? change.moved.length : 0) + (change && change.new_due_date !== change.old_due_date ? 1 : 0);

  return (
    <div
      className="ab-overlay"
      onMouseDown={(e) => {
        // Backdrop click dismisses UI only (never cancels).
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="ab-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="ab-confirm-title"
        ref={dialogRef}
      >
        <div className="ab-modal__head">
          <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12 }}>
            <div>
              <h2 className="ab-modal__title" id="ab-confirm-title">
                Review proposed change
              </h2>
              <p className="ab-modal__sub">
                {change && change.status !== "pending"
                  ? `This proposal is already “${change.status}” on the server — the details below are a record, and no further action is possible.`
                  : "Nothing has been applied yet. Review the diff, then confirm."}
              </p>
            </div>
            <button
              type="button"
              className="ab-modal__close"
              aria-label="Close (does not cancel the proposal)"
              onClick={onClose}
            >
              &times;
            </button>
          </div>
        </div>

        <div className="ab-modal__body">
          {phase === "loading" && (
            <>
              <div className="ab-skeleton" style={{ width: "70%" }} />
              <div className="ab-skeleton" style={{ width: "100%", height: 48 }} />
              <div className="ab-skeleton" style={{ width: "100%", height: 48 }} />
            </>
          )}

          {phase === "error" && (
            <div className="ab-banner ab-banner--error" role="alert">
              <div>
                <strong>Unable to load this change.</strong>
                <div>{loadError}</div>
              </div>
            </div>
          )}

          {phase === "ready" && change && (
            <>
              {change.status !== "pending" && (
                <div className="ab-banner ab-banner--warning" role="status">
                  <div>
                    This proposal is already <strong>{change.status}</strong> on the
                    server, so it can no longer be applied.
                  </div>
                </div>
              )}

              <div>
                <div className="ab-card__hint" style={{ marginBottom: 6 }}>
                  {change.status === "pending"
                    ? "Summary"
                    : // The backend stores this text when the proposal is created and
                      // never rewrites it, so an applied/cancelled record still says
                      // "pending confirmation". Label it as history instead of editing
                      // the server's words.
                      `Summary recorded when this was proposed (server status now: ${change.status})`}
                </div>
                <p style={{ margin: 0, fontSize: 14, lineHeight: 1.5 }}>{change.summary}</p>
              </div>

              <div className="ab-diff">
                <div className="ab-card__hint">Primary commitment (#{change.commitment_id})</div>
                <div className="ab-diff__row">
                  <span className="ab-datepill ab-datepill--old">{change.old_due_date}</span>
                  <span className="ab-arrow" aria-hidden>
                    &rarr;
                  </span>
                  <span className="ab-datepill ab-datepill--new">{change.new_due_date}</span>
                  <span className="ab-badge ab-badge--primary" style={{ marginLeft: "auto" }}>
                    {affectedCount} task{affectedCount === 1 ? "" : "s"} affected
                  </span>
                </div>
              </div>

              {change.moved.length > 0 && (
                <div className="ab-diff">
                  <div className="ab-card__hint">Rebalanced to avoid conflicts</div>
                  {change.moved.map((m) => (
                    <div className="ab-diff__row" key={`${m.commitment_id}-${m.to}`}>
                      <div className="ab-row__main" style={{ flex: "1 1 auto" }}>
                        <div className="ab-row__title" title={m.title}>
                          {m.title}
                        </div>
                        <div className="ab-row__meta">{m.reason}</div>
                      </div>
                      <span className="ab-datepill ab-datepill--old">{m.from}</span>
                      <span className="ab-arrow" aria-hidden>
                        &rarr;
                      </span>
                      <span className="ab-datepill ab-datepill--new">{m.to}</span>
                    </div>
                  ))}
                </div>
              )}

              {change.moved.length === 0 && (
                <div className="ab-note">
                  No other tasks needed rebalancing for this proposal.
                </div>
              )}

              {actionError && (
                <div className="ab-banner ab-banner--error" role="alert">
                  <div>{actionError}</div>
                </div>
              )}
            </>
          )}
        </div>

        <div className="ab-modal__foot">
          <button
            type="button"
            className="ab-btn ab-btn--ghost"
            onClick={onClose}
            disabled={busy !== "idle"}
          >
            Close
          </button>
          <button
            type="button"
            className="ab-btn ab-btn--danger"
            onClick={handleCancel}
            disabled={phase !== "ready" || busy !== "idle" || !stillPending}
          >
            {busy === "cancelling" ? "Cancelling…" : "Cancel proposal"}
          </button>
          <button
            ref={primaryRef}
            type="button"
            className="ab-btn ab-btn--primary"
            onClick={handleApply}
            disabled={phase !== "ready" || busy !== "idle" || !stillPending}
          >
            {busy === "applying" ? "Applying…" : "Apply changes"}
          </button>
        </div>
      </div>
    </div>
  );
}
